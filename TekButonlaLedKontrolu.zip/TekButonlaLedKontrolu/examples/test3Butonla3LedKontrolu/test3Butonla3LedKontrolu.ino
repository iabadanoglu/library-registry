#include <TekButonlaLedKontrolu.h>

TekButonlaLedKontrolu yellowLedControl (6, 10, true, "Sari led yaniyor", "Sari led yanmiyor");
TekButonlaLedKontrolu greenLedControl (4, 11, true, "Yesil led yaniyor", "Yesil led yanmiyor");
TekButonlaLedKontrolu redLedControl (2, 12, true, "Kirmizi led yaniyor", "Kirmizi led yanmiyor");

void setup() {
  yellowLedControl.begin();
  greenLedControl.begin();
  redLedControl.begin();
}

void loop() {
  yellowLedControl.update();
  greenLedControl.update();
  redLedControl.update();
}
