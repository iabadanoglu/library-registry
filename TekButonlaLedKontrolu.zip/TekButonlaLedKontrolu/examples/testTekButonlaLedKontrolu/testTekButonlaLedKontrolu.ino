#include <TekButonlaLedKontrolu.h>

TekButonlaLedKontrolu ledCtrl(6, 12, true, "Led yaniyor", "Led sonuk");

void setup() {
  ledCtrl.begin();
}

void loop() {
  ledCtrl.update();
}
