#include "TekButonlaLedKontrolu.h"

TekButonlaLedKontrolu::TekButonlaLedKontrolu(int btnPin, int ledPin, bool showState, String msgLedOn, String msgLedOff) {
  buttonPIN = btnPin;
  ledPIN = ledPin;
  showLedState = showState;
  buttonPressed = false;
  buttonReleased = false;
  ledOn = false;
  messageLedOn = msgLedOn;
  messageLedOff = msgLedOff;
}

void TekButonlaLedKontrolu::begin() {
  if (showLedState) Serial.begin(9600);
  pinMode(buttonPIN, INPUT_PULLUP);
  pinMode(ledPIN, OUTPUT);
}

void TekButonlaLedKontrolu::update() {
  if (checkButton()) toggleLed();
}

bool TekButonlaLedKontrolu::checkButton() {
  bool pressed = false;
  buttonPressed = !digitalRead(buttonPIN);

  if (buttonPressed != buttonReleased) {
    if (buttonPressed) pressed = true;
  }

  buttonReleased = buttonPressed;
  return pressed;
}

void TekButonlaLedKontrolu::toggleLed() {
  ledOn = !ledOn;
  digitalWrite(ledPIN, ledOn);

  if (showLedState) {
    if (ledOn) printState(messageLedOn);
    else printState(messageLedOff);
  }
}

void TekButonlaLedKontrolu::setLed(bool state) {
  ledOn = state;
  digitalWrite(ledPIN, ledOn);
  if (showLedState) {
    if (ledOn) printState(messageLedOn);
    else printState(messageLedOff);
  }
}

void TekButonlaLedKontrolu::printState(const String &str) {
  Serial.println(str);
}
