#ifndef TEKBUTONLALEDKONTROLU_H
#define TEKBUTONLALEDKONTROLU_H

#include <Arduino.h>

class TekButonlaLedKontrolu 
{
  private:
    int buttonPIN;
    int ledPIN;
    bool buttonPressed;
    bool buttonReleased;
    bool ledOn;
    bool showLedState;
    String messageLedOn;
    String messageLedOff;

  public:
    // Kurucu
    TekButonlaLedKontrolu(int btnPin, int ledPin, bool showState = true, String msgLedOn = "Led is turned on", String msgLedOff = "Led is turned off");

    void begin();
    void update();
    void toggleLed();
    void setLed(bool state);
    bool checkButton();
    void printState(const String &str);
};

#endif
